from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.utils import timezone
from main.models import Todo
from django.http import HttpResponseRedirect



# Create your views here.
def home(request):
  todo_items = Todo.objects.all().order_by("-added_date")
  return render(request, 'main/index.html',{"todo_items":todo_items})

@csrf_exempt
def add_todo(request):
  current_date = timezone.now()
  content = request.POST["content"]
  object_created = Todo.objects.create(added_date = current_date, text = content)
  return  HttpResponseRedirect("/")

@csrf_exempt
def del_todo(request, todoitems_id):
  Todo.objects.get(id=todoitems_id).delete()
  return  HttpResponseRedirect("/")



